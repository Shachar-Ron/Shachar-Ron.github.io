
public enum TopSpinPuzzleMove
{
	LEFT
	{
        public String toString()
        {
            return "LEFT";
        }
	}, 
    RIGHT
    {
        public String toString()
        {
            return "RIGHT";
        }
	}, 
    SWAP
    {
        public String toString()
        {
            return "SWAP";
        }
	}
}

