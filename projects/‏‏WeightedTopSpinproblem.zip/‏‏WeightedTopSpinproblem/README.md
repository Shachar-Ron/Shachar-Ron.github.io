# Weighted-TopSpin-problem-
AI-Development system that solves the Weighted TopSpin problem with the implementation of A* algorithm and selecting an admissible Heuristic algorithm.
