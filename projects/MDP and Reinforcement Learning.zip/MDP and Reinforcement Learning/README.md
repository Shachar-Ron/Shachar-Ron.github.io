AI- Build a robot that can plan its path intelligently so as to maximize the expected utility with Markov Decision Process and Value Iteration  OR with  Reinforcement Learning with Q-Learning.
