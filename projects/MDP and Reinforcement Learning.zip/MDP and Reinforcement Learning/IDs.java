import java.util.ArrayList;
import java.util.List;

public class IDs {

    //todo replace empty strings with your IDs

    public static List<String> getIDs()
    {
        List<String> ids = new ArrayList<String>();

        String id1 = "";
        String id2 = "";
        //String id3 = "";

        ids.add(id1);
        ids.add(id2);
        //ids.add(id3);

        return ids;
    }
}
