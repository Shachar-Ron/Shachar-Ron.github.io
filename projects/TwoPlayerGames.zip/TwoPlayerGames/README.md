AI-Development system that solves the Weighted Othello game with the implementation of Alpha-Beta Pruning algorithm.
