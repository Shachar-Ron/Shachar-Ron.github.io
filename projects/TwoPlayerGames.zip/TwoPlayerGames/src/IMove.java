
public interface IMove 
{

}
