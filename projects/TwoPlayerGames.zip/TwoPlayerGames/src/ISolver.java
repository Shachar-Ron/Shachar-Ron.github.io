
public interface ISolver 
{			
	public double 	solve(IBoard board);	
	
	public String	getSolverName();
}
