import java.util.ArrayList;
import java.util.List;

public class IDs 
{
	public static List<String> getIDs()
	{
		List<String> ids = new ArrayList<String>();
		
		String id1 = "203018254";
		String id2 = "308339597";
		//String id3 = "123456789";
		
		ids.add(id1);
		ids.add(id2);
		//ids.add(id3);
		
		return ids;
	}
}
