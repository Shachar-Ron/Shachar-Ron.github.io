package Model.Exeptions;

public class NoPathToSaveResultsExeption extends Exception {
}
