package Model.Exeptions;

public class NoCorpusPathExeption extends Exception {
}
