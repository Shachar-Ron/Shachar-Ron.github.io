package Model.Exeptions;

public class NoDicInTheFileExeptionExeption extends Exception{
}
