package Model.Exeptions;

public class NoDictenoryLoadedExeption extends Exception {
}
