package Model.Exeptions;

public class EmptyTextFieldExeption extends Exception {
}
