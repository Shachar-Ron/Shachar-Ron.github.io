package Model.Exeptions;

public class NoIndexerPathInsertedExeption extends Exception {
}
